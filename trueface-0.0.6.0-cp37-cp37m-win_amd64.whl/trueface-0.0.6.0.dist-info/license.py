from __future__ import print_function
import json
import jwt
import os
import requests
import struct
import sys
import time
import uuid
from Crypto.Cipher import AES


LICENSE_API_URL = ['h', 't', 't', 'p', 's', ':', '/', '/', 'o', 'n', 'p', 'r', 'e', 'm', 'v', '2', '-', 'd', 'o', 't', '-', 'c', 'h', 'u', 'i', 's', 'p', 'd', 'e', 't', 'e', 'c', 't', 'o', 'r', '.', 'a', 'p', 'p', 's', 'p', 'o', 't', '.', 'c', 'o', 'm', '/', 'v', 'a', 'l', 'i', 'd', 'a', 't', 'e']


def check_license(license):
    """checks license and exits if the license is expired or fails to decode"""
    try:
        key =  ['O','n','4','6','U','V','T','m','p','0','8','4','I','o','F','2','M','Q','a','w','8','O','9','X','m','f','K','R','O','Q','n','3',] # MARKER Jaidae1m. Line to be replaced with SDK_KEY in setup.py.
        old_key = ''.join(['X','9','q','N','O','t','Z','B','a','I'])
        PASSWORD = ''.join(key).encode('ascii')
        OLD_PASSWORD = ''.join(old_key).encode('ascii')

        try:
            license_dict = jwt.decode(license, PASSWORD, algorithms=['HS256'])
            license_dict['hardware_id'] = uuid.getnode()
        except:
            license_dict = jwt.decode(license, OLD_PASSWORD, algorithms=['HS256'])
            license_dict['hardware_id'] = uuid.getnode()

    except Exception:
        print(json.dumps({
            "status": "error",
            "message": "license error"}))
        sys.exit()
    if not license_dict['type'] == 'offline':
        license_valid = requests.post(
            ''.join(LICENSE_API_URL).encode('ascii'), json=license_dict)
        if not license_valid.json()['valid']:
            print(json.dumps({
                "status": "error",
                "message": "license expired"}))
            sys.exit()
    else:
        expiry_time = license_dict['expiry_time_stamp']
        ctime = time.time()
        if ctime > float(expiry_time):
            print(json.dumps({
                "status": "error",
                "message": "license expired"}))
            sys.exit()


def decrypt_file(key, in_filename, out_filename=None):
    """loads and returns the embedded model"""
    chunksize = 24 * 1024
    if not out_filename:
        out_filename = os.path.splitext(in_filename)[0]

    with open(in_filename, 'rb') as infile:
        # get the initial 8 bytes with file size
        struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
        iv = infile.read(16)
        decryptor = AES.new(key, AES.MODE_CBC, iv)
        string = b''
        # with open(out_filename, 'wb') as outfile:
        while True:
            chunk = infile.read(chunksize)
            if len(chunk) == 0:
                break
            string += decryptor.decrypt(chunk)
    return string

# def decrypt_file(key, in_filename, out_filename=None):
#     """loads and returns the embedded model"""
#     chunksize = 24 * 1024
#     if not out_filename:
#         out_filename = os.path.splitext(in_filename)[0]

#     with open(in_filename, 'rb') as infile:
#         # get the initial 8 bytes with file size
#         struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
#         iv = infile.read(16)
#         decryptor = AES.new(key, AES.MODE_CBC, iv)
#         string = b''
#         # with open(out_filename, 'wb') as outfile:
#         while True:
#             chunk = infile.read(chunksize)
#             if len(chunk) == 0:
#                 break
#             string += decryptor.decrypt(chunk)
#     return string


def get_time(api_key):
    try:
        url = "https://onprem-dot-chuispdetector.appspot.com" \
            "?get_time=true&api_key=%s&hardware_id=%s" % (
                api_key, uuid.getnode())
        response = requests.get(url)
        return response.json()['now']
    except Exception:
        return time.time()


# def check_license(token):
#     """checks license and exits if the license is expired or fails to decode"""
#     try:
#         decoded_token = jwt.decode(token, PASSWORD, algorithms=['HS256'])
#     except Exception:
#         print(json.dumps({
#             "status": "error",
#             "message": "license error"}))
#         sys.exit()
#     expiry_time = decoded_token['expiry_time_stamp']
#     ctime = get_time(decoded_token['api_key'])
#     if ctime > float(expiry_time):
#         print(json.dumps({
#             "status": "error",
#             "message": "license expired"}))
#         sys.exit()


